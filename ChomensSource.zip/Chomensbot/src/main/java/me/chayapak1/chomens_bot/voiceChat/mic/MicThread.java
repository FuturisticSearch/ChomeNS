/*
 * Decompiled with CFR 0.152.
 */
package me.chayapak1.chomens_bot.voiceChat.mic;

public class MicThread
extends Thread {
}


/*
 * Decompiled with CFR 0.152.
 */
package me.chayapak1.chomens_bot.data.entity;

public record Rotation(float yaw, float pitch) {
}


/*
 * Decompiled with CFR 0.152.
 */
package me.chayapak1.chomens_bot.data.voiceChat;

public enum Codec {
    VOIP,
    AUDIO,
    RESTRICTED_LOWDELAY;

}


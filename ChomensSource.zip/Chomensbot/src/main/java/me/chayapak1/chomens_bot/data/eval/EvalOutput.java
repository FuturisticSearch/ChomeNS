/*
 * Decompiled with CFR 0.152.
 */
package me.chayapak1.chomens_bot.data.eval;

public record EvalOutput(boolean isError, String output) {
}


/*
 * Decompiled with CFR 0.152.
 */
package me.chayapak1.chomens_bot.command;

public final class CommonFlags {
    public static final String IGNORE_CASE = "ignorecase";
    public static final String REGEX = "regex";
}


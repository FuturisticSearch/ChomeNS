/*
 * Decompiled with CFR 0.152.
 */
package me.chayapak1.chomens_bot.data.filter;

public record PlayerFilter(String playerName, String reason, boolean regex, boolean ignoreCase) {
}

